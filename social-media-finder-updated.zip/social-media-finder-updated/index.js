// Root endpoint to verify the API is running
module.exports = (req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept');
  
  // Return API information
  res.json({
    status: "online",
    message: "Social Media Finder API is running",
    endpoints: {
      root: "/",
      api: "/api/search-image"
    },
    version: "1.0.0",
    documentation: "Send POST requests to /api/search-image with an image in the request body"
  });
};