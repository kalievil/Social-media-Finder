// Simplified API for Social Media Finder Extension
// Returns mock data for demonstration purposes

// Main handler function
module.exports = async (req, res) => {
  // Set CORS headers for all requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  // For GET requests, return helpful information instead of an error
  if (req.method === 'GET') {
    return res.json({
      message: "This endpoint expects a POST request with an image in the body",
      usage: {
        method: "POST",
        contentType: "application/json",
        body: {
          image: "base64EncodedImageString"
        }
      }
    });
  }
  
  // Only accept POST requests for actual processing
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  
  try {
    // Log the request
    console.log('Received image search request');
    
    // Sample mock profiles
    const mockProfiles = [
      {
        name: "John Smith",
        instagram: "https://www.instagram.com/johnsmith",
        linkedin: "https://www.linkedin.com/in/john-smith-123456",
        twitter: "https://twitter.com/johnsmith"
      },
      {
        name: "Emma Johnson",
        instagram: "https://www.instagram.com/emmaj",
        linkedin: "https://www.linkedin.com/in/emma-johnson",
        twitter: "https://twitter.com/emmaj"
      }
    ];
    
    // Return mock results
    return res.status(200).json({
      success: true,
      profiles: mockProfiles
    });
    
  } catch (error) {
    console.error('Error in API:', error);
    return res.status(500).json({ error: 'Internal server error', details: error.message });
  }
};