// Root endpoint to verify the API is running
module.exports = (req, res) => {
  res.json({
    status: "online",
    message: "Social Media Finder API is running",
    endpoint: "/api/search-image"
  });
}; 